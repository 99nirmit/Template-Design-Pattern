package com.pattern.abstractfactory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AbstractfactoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
